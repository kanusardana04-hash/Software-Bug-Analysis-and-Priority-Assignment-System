const $ = id => document.getElementById(id);
const LABEL = {P1: 'Critical', P2: 'High', P3: 'Medium', P4: 'Low'};
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let bugs = [];

function formData() {
  return {
    title: $('title').value.trim(),
    module: $('module').value.trim() || 'General',
    description: $('description').value.trim(),
    severity: +$('severity').value,
    reproducibility: +$('reproducibility').value,
    usersAffected: Math.max(0, parseInt($('usersAffected').value) || 0)
  };
}

async function api(path, opts = {}) {
  const res = await fetch('/api' + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

let previewTimer;
function schedulePreview() {
  $('sevVal').textContent = $('severity').value;
  $('repVal').textContent = $('reproducibility').value;
  clearTimeout(previewTimer);
  previewTimer = setTimeout(async () => {
    const d = formData();
    if (!d.title) { $('preview').textContent = 'Priority preview will appear here…'; return; }
    try {
      const r = await api('/analyze', { method: 'POST', body: JSON.stringify(d) });
      $('preview').innerHTML = `Predicted: <span class="badge ${r.priority}">${r.priority} – ${LABEL[r.priority]}</span> &nbsp; Score <b>${r.score}</b> &nbsp; Category <b>${esc(r.category)}</b>` +
        (r.duplicateOf ? ` &nbsp; <span class="dup">⚠ Possible duplicate of #${r.duplicateOf}</span>` : '');
    } catch (e) { $('preview').textContent = e.message; }
  }, 250);
}

async function submitBug() {
  const d = formData();
  if (!d.title) { $('msg').textContent = 'Title is required.'; return; }
  try {
    const r = await api('/bugs', { method: 'POST', body: JSON.stringify(d) });
    $('msg').textContent = `Saved as #${r.id} → ${r.priority} (${r.score})`;
    ['title', 'module', 'description'].forEach(i => $(i).value = '');
    schedulePreview();
    load();
  } catch (e) { $('msg').textContent = e.message; }
}

async function setStatus(id, status) { await api('/bugs/' + id, { method: 'PUT', body: JSON.stringify({ status }) }); load(); }
async function removeBug(id) { if (confirm('Delete bug #' + id + '?')) { await api('/bugs/' + id, { method: 'DELETE' }); load(); } }

function render() {
  const fp = $('fPriority').value, fs = $('fStatus').value, q = $('search').value.toLowerCase();
  const list = bugs.filter(b => (!fp || b.priority === fp) && (!fs || b.status === fs) &&
    (!q || (b.title + ' ' + b.description + ' ' + b.module).toLowerCase().includes(q)));
  $('rows').innerHTML = list.length ? list.map(b => `
    <tr class="${b.status === 'Resolved' || b.status === 'Closed' ? 'done' : ''}">
      <td>#${b.id}</td>
      <td><span class="badge ${b.priority}">${b.priority} ${LABEL[b.priority]}</span></td>
      <td><b>${b.score}</b></td>
      <td>${esc(b.title)}${b.duplicateOf ? `<span class="dup">⚠ possible duplicate of #${b.duplicateOf}</span>` : ''}<small>${esc(b.description).slice(0, 90)}</small></td>
      <td>${esc(b.category)}</td><td>${esc(b.module)}</td><td>${b.usersAffected}</td>
      <td><select onchange="setStatus(${b.id}, this.value)">
        ${['Open', 'In Progress', 'Resolved', 'Closed'].map(s => `<option ${s === b.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
      <td><button class="del" onclick="removeBug(${b.id})">Delete</button></td>
    </tr>`).join('') : '<tr><td colspan="9">No bugs found.</td></tr>';
}

async function load() {
  bugs = await api('/bugs');
  const s = await api('/stats');
  $('stats').innerHTML = `
    <div class="stat"><b>${s.total}</b><span>Total bugs</span></div>
    <div class="stat"><b style="color:#d62839">${s.byPriority.P1}</b><span>P1 Critical</span></div>
    <div class="stat"><b style="color:#f07f1f">${s.byPriority.P2}</b><span>P2 High</span></div>
    <div class="stat"><b style="color:#b38f00">${s.byPriority.P3}</b><span>P3 Medium</span></div>
    <div class="stat"><b style="color:#2e9e6a">${s.byPriority.P4}</b><span>P4 Low</span></div>
    <div class="stat"><b>${(+s.avgScore).toFixed(1)}</b><span>Avg score</span></div>`;
  render();
}

['title', 'module', 'description', 'severity', 'reproducibility', 'usersAffected'].forEach(i => $(i).addEventListener('input', schedulePreview));
['fPriority', 'fStatus', 'search'].forEach(i => $(i).addEventListener('input', render));
$('submit').addEventListener('click', submitBug);
load();
