# Software Bug Analysis and Priority Assignment System
**Project Report**

Name: ____________  Roll No: ____________  Course: ____________  Teacher: ____________  Date: ____________

## 1. Abstract
Software teams receive many bug reports and must decide which to fix first. Doing this by hand is slow and subjective. This project builds a web-based system whose backend is written in C++ and which analyses each reported bug, detects its category, checks for duplicates and assigns a numeric priority score and a priority level (P1-P4). A browser frontend lets users report, view, filter and track bugs.

## 2. Introduction
A bug tracker normally stores bugs but leaves prioritisation to people. Wrong prioritisation causes critical defects (security holes, crashes, data loss) to wait while cosmetic issues get fixed. This system provides a consistent, explainable and automatic priority assignment so teams can focus on what matters most.

## 3. Objectives
1. Accept bug reports with the key factors that decide urgency.
2. Analyse the text of a report and classify it into a category.
3. Compute a priority score and assign P1-P4 automatically.
4. Detect probable duplicate reports.
5. Provide a usable web interface and a REST API, deployed online.

## 4. Requirements
**Functional:** create bug; list bugs sorted by priority; update status (Open, In Progress, Resolved, Closed); delete bug; preview priority; statistics; filter and search.
**Non-functional:** no external dependencies in the backend; responds in milliseconds; data persists across restarts; input validated; works in modern browsers and on mobile screens.

## 5. System Design
### 5.1 Architecture
```
Browser (HTML/CSS/JS)  --HTTP/JSON-->  C++ server (POSIX sockets, thread per request)
                                          |-- analyzer.hpp (scoring, categories, duplicates)
                                          |-- store.hpp    (thread-safe storage -> data/bugs.tsv)
                                          |-- json.hpp     (JSON helpers)
```
The same C++ process serves the static frontend files and the REST API, so deployment is one container.

### 5.2 Data model (Bug)
id, title, description, module, status, category, priority, severity (1-5), usersAffected, reproducibility (1-5), score (0-100), createdAt, duplicateOf.

### 5.3 Priority assignment algorithm
Four factors are normalised to 0-1 and combined with weights:

| Factor | Weight | How it is measured |
|---|---|---|
| Severity | 40% | user input 1-5, divided by 5 |
| User impact | 25% | log10(users+1)/4, capped at 1 (10,000 users = max) |
| Reproducibility | 20% | user input 1-5, divided by 5 |
| Keyword risk | 15% | highest weight keyword found in title/description |

`score = 100 x (0.40 S + 0.25 I + 0.20 R + 0.15 K)`

Priority levels: **P1 Critical** >= 75, **P2 High** >= 55, **P3 Medium** >= 35, **P4 Low** < 35.

A logarithmic scale is used for impact because the difference between 10 and 100 affected users matters more than between 10,000 and 10,090.

### 5.4 Bug analysis (category detection)
The text is lower-cased and scanned for a dictionary of risk keywords, each with a weight and a category, for example: *injection, vulnerability* -> Security (1.0); *data loss, corrupt* -> Data Integrity (0.9-0.95); *crash, deadlock, freeze* -> Stability (0.75-0.9); *payment, checkout, login* -> Business Critical; *slow, timeout* -> Performance (0.5); *wrong, error* -> Functional; *typo, colour, alignment* -> UI/Cosmetic (0.1). The match with the highest weight decides both the keyword-risk factor and the category. If nothing matches, a neutral weight of 0.2 and category "General" are used.

### 5.5 Duplicate detection
Titles are split into word sets (words longer than 2 characters). The Jaccard similarity |A intersect B| / |A union B| is computed against every non-closed bug. If the best similarity is >= 0.6, the new bug is flagged as a possible duplicate of that bug.

### 5.6 REST API
See README. Endpoints: GET/POST /api/bugs, POST /api/analyze, PUT/DELETE /api/bugs/{id}, GET /api/stats, GET /api/health.

### 5.7 Frontend
Single-page interface: statistics cards, a bug-report form with a live priority preview (calls /api/analyze while typing), and a table with colour-coded priority badges, filter by priority/status, text search, status dropdown and delete. All user text is HTML-escaped before display to prevent XSS.

## 6. Implementation
- **Language/tools:** C++17, g++, Make, POSIX sockets and std::thread; HTML5, CSS3, vanilla JavaScript; Docker for deployment.
- **Concurrency:** one thread per connection; a std::mutex protects the bug store.
- **Persistence:** tab-separated file, rewritten on every change; priorities are recomputed on load so formula changes apply to old data.
- **Security/robustness:** request size capped at 1 MB, socket read timeout, path traversal (`..`) blocked, input clamped to valid ranges, title validated, status validated against an allowed list.

## 7. Testing
Unit tests (`make test`, backend/tests/test_analyzer.cpp) check:

| Test | Expected | Result |
|---|---|---|
| SQL injection, severity 5, 20,000 users | P1, category Security | Pass |
| Typo in a label, severity 1 | P4, category UI/Cosmetic | Pass |
| Crash on export, severity 3, 200 users | P2 or P3, category Stability | Pass |
| Same bug with higher severity | Higher score | Pass |
| Out-of-range inputs (99, -5, 0) | Clamped to 5, 0, 1; score within 0-100 | Pass |
| Near-identical title | Detected as duplicate | Pass |
| Unrelated title | Not a duplicate | Pass |

API tests with curl: health, list (sorted P1 first), create (201), duplicate flagged (#6 flagged as duplicate of #2), status update, statistics, static file serving (200), path traversal (404), empty title (400). All behaved as expected.

Sample result on the demo data:

| ID | Title | Priority | Score | Category |
|---|---|---|---|---|
| 1 | SQL injection on login form | P1 | 100 | Security |
| 2 | App crashes when exporting PDF | P1 | 76.7 | Stability |
| 4 | Payment fails for large orders | P1 | 76.0 | Business Critical |
| 5 | Dashboard loads slowly on mobile | P2 | 58.4 | Performance |
| 3 | Typo in settings heading | P3 | 46.4 | UI/Cosmetic |

## 8. Deployment
The project is containerised (multi-stage Dockerfile: build with gcc, run on debian-slim) and deployed on Render as a web service. Live link: **https://<your-app>.onrender.com** (replace with your link).
GitHub repository: **https://github.com/<username>/<repo>**

## 9. Limitations
- Keyword matching is simple and English-only; it does not understand context.
- Weights are chosen by judgement, not learned from real data.
- A flat file is used instead of a database; there is no login or user roles.
- The free hosting tier may reset stored data on restart.

## 10. Future Work
Use machine learning (e.g. TF-IDF + classifier) trained on real bug data; SQLite/PostgreSQL storage; authentication and roles; assignment of bugs to developers; email notifications; charts and trend reports.

## 11. Conclusion
The system meets its objectives: it analyses bug reports, categorises them, detects duplicates, and assigns an explainable priority from P1 to P4 through a C++ backend and a web frontend, with tests and a deployable container. It shows how simple weighted scoring can make bug triage faster and more consistent.

## 12. References
1. IEEE Std 1044-2009, Standard Classification for Software Anomalies.
2. Sommerville, I., *Software Engineering*, Pearson.
3. Jaccard similarity coefficient - standard set-similarity measure.
4. cppreference.com - C++17 standard library documentation.
