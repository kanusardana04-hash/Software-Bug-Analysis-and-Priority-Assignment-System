#pragma once
// Core logic: bug analysis (category detection, duplicate detection) and priority scoring.
#include <algorithm>
#include <cctype>
#include <cmath>
#include <set>
#include <string>
#include <utility>
#include <vector>

struct Bug {
    int id = 0;
    std::string title, description, module;
    std::string status = "Open";     // Open | In Progress | Resolved | Closed
    std::string category = "General";
    std::string priority = "P4";     // P1 (Critical) .. P4 (Low)
    std::string createdAt;
    int severity = 3;                // 1 (minor) .. 5 (blocker)
    int usersAffected = 1;           // estimated number of users impacted
    int reproducibility = 3;         // 1 (rare) .. 5 (always)
    double score = 0.0;              // 0..100
    int duplicateOf = 0;             // id of a likely duplicate, 0 if none
};

namespace analyzer {

inline std::string lower(std::string s) {
    for (auto& c : s) c = (char)std::tolower((unsigned char)c);
    return s;
}

inline int clampInt(int v, int lo, int hi) { return std::max(lo, std::min(hi, v)); }

struct Keyword { const char* word; double weight; const char* category; };

inline const std::vector<Keyword>& keywords() {
    static const std::vector<Keyword> k = {
        {"vulnerab", 1.0, "Security"}, {"injection", 1.0, "Security"}, {"xss", 1.0, "Security"},
        {"password", 0.9, "Security"}, {"breach", 1.0, "Security"}, {"unauthorized", 1.0, "Security"},
        {"data loss", 0.95, "Data Integrity"}, {"corrupt", 0.9, "Data Integrity"},
        {"deleted", 0.8, "Data Integrity"}, {"lost data", 0.95, "Data Integrity"},
        {"crash", 0.85, "Stability"}, {"segfault", 0.9, "Stability"}, {"freeze", 0.75, "Stability"},
        {"hang", 0.75, "Stability"}, {"exception", 0.7, "Stability"}, {"deadlock", 0.9, "Stability"},
        {"payment", 0.85, "Business Critical"}, {"checkout", 0.8, "Business Critical"},
        {"login", 0.7, "Business Critical"},
        {"slow", 0.5, "Performance"}, {"timeout", 0.55, "Performance"},
        {"memory leak", 0.7, "Performance"}, {"lag", 0.45, "Performance"},
        {"wrong", 0.45, "Functional"}, {"incorrect", 0.45, "Functional"}, {"fail", 0.5, "Functional"},
        {"error", 0.5, "Functional"}, {"not working", 0.55, "Functional"},
        {"typo", 0.1, "UI/Cosmetic"}, {"alignment", 0.15, "UI/Cosmetic"}, {"color", 0.1, "UI/Cosmetic"},
        {"colour", 0.1, "UI/Cosmetic"}, {"cosmetic", 0.1, "UI/Cosmetic"}, {"spacing", 0.1, "UI/Cosmetic"},
    };
    return k;
}

// Highest-weight keyword found in the text -> (weight, category)
inline std::pair<double, std::string> scanKeywords(const std::string& text) {
    std::string t = lower(text);
    double best = 0.2;
    std::string cat = "General";
    bool found = false;
    for (const auto& k : keywords()) {
        if (t.find(k.word) != std::string::npos && (!found || k.weight > best)) {
            best = k.weight;
            cat = k.category;
            found = true;
        }
    }
    return {best, cat};
}

inline std::string priorityFor(double score) {
    if (score >= 75) return "P1";
    if (score >= 55) return "P2";
    if (score >= 35) return "P3";
    return "P4";
}

// Weighted formula (0..100): 40% severity, 25% user impact (log scale),
// 20% reproducibility, 15% keyword risk.
inline void assignPriority(Bug& b) {
    b.severity = clampInt(b.severity, 1, 5);
    b.reproducibility = clampInt(b.reproducibility, 1, 5);
    if (b.usersAffected < 0) b.usersAffected = 0;
    double sev = b.severity / 5.0;
    double impact = std::min(1.0, std::log10(b.usersAffected + 1.0) / 4.0);  // 10,000 users => 1.0
    double repro = b.reproducibility / 5.0;
    auto kw = scanKeywords(b.title + " " + b.description);
    b.category = kw.second;
    double score = 100.0 * (0.40 * sev + 0.25 * impact + 0.20 * repro + 0.15 * kw.first);
    b.score = std::round(score * 10.0) / 10.0;
    b.priority = priorityFor(b.score);
}

inline std::set<std::string> tokens(const std::string& s) {
    std::set<std::string> out;
    std::string cur;
    for (char ch : lower(s)) {
        if (std::isalnum((unsigned char)ch)) cur += ch;
        else { if (cur.size() > 2) out.insert(cur); cur.clear(); }
    }
    if (cur.size() > 2) out.insert(cur);
    return out;
}

// Jaccard similarity of word sets (0..1)
inline double similarity(const std::string& a, const std::string& b) {
    auto ta = tokens(a), tb = tokens(b);
    if (ta.empty() || tb.empty()) return 0.0;
    size_t inter = 0;
    for (const auto& w : ta) if (tb.count(w)) ++inter;
    size_t uni = ta.size() + tb.size() - inter;
    return uni ? (double)inter / (double)uni : 0.0;
}

inline int findDuplicate(const Bug& nb, const std::vector<Bug>& existing, double threshold = 0.6) {
    int best = 0;
    double bestSim = threshold;
    for (const auto& e : existing) {
        if (e.status == "Closed") continue;
        double s = similarity(nb.title, e.title);
        if (s >= bestSim) { bestSim = s; best = e.id; }
    }
    return best;
}

}  // namespace analyzer
