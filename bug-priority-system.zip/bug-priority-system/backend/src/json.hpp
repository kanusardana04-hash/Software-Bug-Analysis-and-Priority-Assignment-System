#pragma once
// Tiny JSON helpers (flat objects only) - no external libraries needed.
#include <string>
#include <cstdlib>

inline std::string jsonEscape(const std::string& s) {
    std::string o;
    for (unsigned char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if (c < 0x20) o += ' ';
                else o += (char)c;
        }
    }
    return o;
}

inline size_t jsonFindValue(const std::string& body, const std::string& key) {
    size_t p = body.find("\"" + key + "\"");
    if (p == std::string::npos) return std::string::npos;
    p = body.find(':', p);
    if (p == std::string::npos) return std::string::npos;
    ++p;
    while (p < body.size() && (body[p] == ' ' || body[p] == '\n' || body[p] == '\t' || body[p] == '\r')) ++p;
    return p;
}

inline std::string jsonGetString(const std::string& body, const std::string& key, const std::string& def = "") {
    size_t p = jsonFindValue(body, key);
    if (p == std::string::npos || p >= body.size()) return def;
    if (body[p] != '"') {
        size_t e = body.find_first_of(",}", p);
        std::string t = body.substr(p, e == std::string::npos ? std::string::npos : e - p);
        while (!t.empty() && t.back() == ' ') t.pop_back();
        return t;
    }
    std::string out;
    for (++p; p < body.size() && body[p] != '"'; ++p) {
        if (body[p] == '\\' && p + 1 < body.size()) {
            ++p;
            switch (body[p]) {
                case 'n': out += '\n'; break;
                case 't': out += '\t'; break;
                case 'r': out += '\r'; break;
                default: out += body[p];
            }
        } else out += body[p];
    }
    return out;
}

inline int jsonGetInt(const std::string& body, const std::string& key, int def) {
    std::string s = jsonGetString(body, key, "");
    if (s.empty()) return def;
    char* end = nullptr;
    long v = std::strtol(s.c_str(), &end, 10);
    if (end == s.c_str()) return def;
    return (int)v;
}
