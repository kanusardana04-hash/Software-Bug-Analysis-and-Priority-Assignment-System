// Software Bug Analysis and Priority Assignment System - HTTP backend (C++17, POSIX sockets)
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <algorithm>
#include <csignal>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <thread>
#include "analyzer.hpp"
#include "json.hpp"
#include "store.hpp"

struct Request { std::string method, path, query, body; };
struct Response { int code = 200; std::string type = "application/json"; std::string body; };

static std::string g_webRoot = "frontend";
static BugStore* g_store = nullptr;

static std::string bugJson(const Bug& b) {
    std::ostringstream o;
    o << "{\"id\":" << b.id << ",\"title\":\"" << jsonEscape(b.title) << "\",\"description\":\""
      << jsonEscape(b.description) << "\",\"module\":\"" << jsonEscape(b.module) << "\",\"status\":\""
      << b.status << "\",\"category\":\"" << jsonEscape(b.category) << "\",\"priority\":\"" << b.priority
      << "\",\"severity\":" << b.severity << ",\"usersAffected\":" << b.usersAffected
      << ",\"reproducibility\":" << b.reproducibility << ",\"score\":" << b.score
      << ",\"createdAt\":\"" << b.createdAt << "\",\"duplicateOf\":" << b.duplicateOf << "}";
    return o.str();
}

static Bug bugFromBody(const std::string& body) {
    Bug b;
    b.title = jsonGetString(body, "title");
    b.description = jsonGetString(body, "description");
    b.module = jsonGetString(body, "module", "General");
    b.severity = jsonGetInt(body, "severity", 3);
    b.usersAffected = jsonGetInt(body, "usersAffected", 1);
    b.reproducibility = jsonGetInt(body, "reproducibility", 3);
    return b;
}

static Response err(int code, const std::string& msg) {
    return {code, "application/json", "{\"error\":\"" + jsonEscape(msg) + "\"}"};
}

static std::string statsJson() {
    auto bugs = g_store->all();
    std::map<std::string, int> byP{{"P1", 0}, {"P2", 0}, {"P3", 0}, {"P4", 0}}, byStatus, byCat, byMod;
    double sum = 0;
    for (const auto& b : bugs) {
        byP[b.priority]++; byStatus[b.status]++; byCat[b.category]++; byMod[b.module]++;
        sum += b.score;
    }
    auto obj = [](const std::map<std::string, int>& m) {
        std::string s = "{"; bool first = true;
        for (const auto& kv : m) { if (!first) s += ","; first = false;
            s += "\"" + jsonEscape(kv.first) + "\":" + std::to_string(kv.second); }
        return s + "}";
    };
    std::ostringstream o;
    o << "{\"total\":" << bugs.size() << ",\"avgScore\":" << (bugs.empty() ? 0.0 : sum / bugs.size())
      << ",\"byPriority\":" << obj(byP) << ",\"byStatus\":" << obj(byStatus)
      << ",\"byCategory\":" << obj(byCat) << ",\"byModule\":" << obj(byMod) << "}";
    return o.str();
}

static std::string mimeFor(const std::string& p) {
    auto ends = [&](const char* e) { std::string s(e); return p.size() >= s.size() && p.compare(p.size() - s.size(), s.size(), s) == 0; };
    if (ends(".html")) return "text/html; charset=utf-8";
    if (ends(".css")) return "text/css";
    if (ends(".js")) return "application/javascript";
    if (ends(".json")) return "application/json";
    if (ends(".svg")) return "image/svg+xml";
    return "application/octet-stream";
}

static Response serveStatic(std::string path) {
    if (path == "/") path = "/index.html";
    if (path.find("..") != std::string::npos) return err(400, "bad path");
    std::ifstream f(g_webRoot + path, std::ios::binary);
    if (!f) return err(404, "not found");
    std::stringstream ss; ss << f.rdbuf();
    return {200, mimeFor(path), ss.str()};
}

static Response route(const Request& r) {
    if (r.method == "OPTIONS") return {204, "text/plain", ""};
    if (r.path.rfind("/api/", 0) != 0) {
        if (r.method != "GET") return err(405, "method not allowed");
        return serveStatic(r.path);
    }
    if (r.path == "/api/health" && r.method == "GET") return {200, "application/json", "{\"status\":\"ok\"}"};

    if (r.path == "/api/bugs" && r.method == "GET") {
        auto bugs = g_store->all();
        std::sort(bugs.begin(), bugs.end(), [](const Bug& a, const Bug& b) {
            bool ad = a.status == "Resolved" || a.status == "Closed", bd = b.status == "Resolved" || b.status == "Closed";
            if (ad != bd) return !ad;                 // active bugs first
            return a.score > b.score;                 // then highest score
        });
        std::string out = "[";
        for (size_t i = 0; i < bugs.size(); ++i) { if (i) out += ","; out += bugJson(bugs[i]); }
        return {200, "application/json", out + "]"};
    }

    if ((r.path == "/api/bugs" || r.path == "/api/analyze") && r.method == "POST") {
        Bug b = bugFromBody(r.body);
        if (b.title.empty() || b.title.size() > 200) return err(400, "title is required (max 200 chars)");
        if (r.path == "/api/analyze") {            // preview only, nothing saved
            analyzer::assignPriority(b);
            b.duplicateOf = analyzer::findDuplicate(b, g_store->all());
            return {200, "application/json", bugJson(b)};
        }
        return {201, "application/json", bugJson(g_store->add(b))};
    }

    if (r.path.rfind("/api/bugs/", 0) == 0) {
        int id = std::atoi(r.path.c_str() + 10);
        if (id <= 0) return err(400, "bad id");
        if (r.method == "PUT") {
            if (!g_store->setStatus(id, jsonGetString(r.body, "status"))) return err(404, "bug not found or invalid status");
            return {200, "application/json", "{\"ok\":true}"};
        }
        if (r.method == "DELETE") {
            if (!g_store->remove(id)) return err(404, "bug not found");
            return {200, "application/json", "{\"ok\":true}"};
        }
    }

    if (r.path == "/api/stats" && r.method == "GET") return {200, "application/json", statsJson()};
    return err(404, "unknown endpoint");
}

static const char* reason(int c) {
    switch (c) { case 200: return "OK"; case 201: return "Created"; case 204: return "No Content";
        case 400: return "Bad Request"; case 404: return "Not Found"; case 405: return "Method Not Allowed";
        default: return "Error"; }
}

static void handleClient(int fd) {
    timeval tv{5, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    std::string data;
    char buf[4096];
    size_t headerEnd = std::string::npos, contentLen = 0;
    while (true) {
        ssize_t n = recv(fd, buf, sizeof buf, 0);
        if (n <= 0) break;
        data.append(buf, (size_t)n);
        if (data.size() > 1 << 20) break;           // 1 MB cap
        if (headerEnd == std::string::npos) {
            headerEnd = data.find("\r\n\r\n");
            if (headerEnd != std::string::npos) {
                std::string h = analyzer::lower(data.substr(0, headerEnd));
                size_t p = h.find("content-length:");
                if (p != std::string::npos) contentLen = (size_t)std::atol(h.c_str() + p + 15);
            }
        }
        if (headerEnd != std::string::npos && data.size() >= headerEnd + 4 + contentLen) break;
    }
    if (headerEnd == std::string::npos) { close(fd); return; }

    Request req;
    std::istringstream first(data.substr(0, data.find("\r\n")));
    std::string target; first >> req.method >> target;
    size_t q = target.find('?');
    req.path = target.substr(0, q);
    if (q != std::string::npos) req.query = target.substr(q + 1);
    req.body = data.substr(headerEnd + 4, contentLen);

    Response res = route(req);
    std::ostringstream out;
    out << "HTTP/1.1 " << res.code << ' ' << reason(res.code) << "\r\nContent-Type: " << res.type
        << "\r\nContent-Length: " << res.body.size()
        << "\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS"
        << "\r\nAccess-Control-Allow-Headers: Content-Type\r\nConnection: close\r\n\r\n" << res.body;
    std::string s = out.str();
    size_t sent = 0;
    while (sent < s.size()) {
        ssize_t n = send(fd, s.data() + sent, s.size() - sent, MSG_NOSIGNAL);
        if (n <= 0) break;
        sent += (size_t)n;
    }
    close(fd);
}

int main() {
    signal(SIGPIPE, SIG_IGN);
    const char* portEnv = std::getenv("PORT");
    const char* rootEnv = std::getenv("WEB_ROOT");
    const char* dataEnv = std::getenv("DATA_FILE");
    int port = portEnv ? std::atoi(portEnv) : 8080;
    if (rootEnv) g_webRoot = rootEnv;
    static BugStore store(dataEnv ? dataEnv : "data/bugs.tsv");
    g_store = &store;

    int srv = socket(AF_INET, SOCK_STREAM, 0);
    int yes = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons((uint16_t)port);
    if (bind(srv, (sockaddr*)&addr, sizeof addr) < 0) { perror("bind"); return 1; }
    listen(srv, 64);
    std::cout << "Bug Priority System running on http://0.0.0.0:" << port << std::endl;
    while (true) {
        int fd = accept(srv, nullptr, nullptr);
        if (fd < 0) continue;
        std::thread(handleClient, fd).detach();
    }
}
