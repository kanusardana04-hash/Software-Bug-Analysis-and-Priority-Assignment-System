#pragma once
// Thread-safe bug store persisted to a tab-separated file.
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>
#include "analyzer.hpp"

class BugStore {
public:
    explicit BugStore(std::string path) : path_(std::move(path)) { load(); }

    std::vector<Bug> all() {
        std::lock_guard<std::mutex> g(m_);
        return bugs_;
    }

    Bug add(Bug b) {
        std::lock_guard<std::mutex> g(m_);
        b.id = nextId_++;
        b.createdAt = now();
        b.status = "Open";
        analyzer::assignPriority(b);
        b.duplicateOf = analyzer::findDuplicate(b, bugs_);
        bugs_.push_back(b);
        save();
        return b;
    }

    bool setStatus(int id, const std::string& status) {
        static const char* ok[] = {"Open", "In Progress", "Resolved", "Closed"};
        bool valid = false;
        for (auto s : ok) if (status == s) valid = true;
        if (!valid) return false;
        std::lock_guard<std::mutex> g(m_);
        for (auto& b : bugs_) if (b.id == id) { b.status = status; save(); return true; }
        return false;
    }

    bool remove(int id) {
        std::lock_guard<std::mutex> g(m_);
        for (auto it = bugs_.begin(); it != bugs_.end(); ++it)
            if (it->id == id) { bugs_.erase(it); save(); return true; }
        return false;
    }

private:
    static std::string now() {
        std::time_t t = std::time(nullptr);
        char buf[32];
        std::strftime(buf, sizeof buf, "%Y-%m-%d %H:%M", std::localtime(&t));
        return buf;
    }
    static std::string clean(std::string s) {
        for (auto& c : s) if (c == '\t' || c == '\n' || c == '\r') c = ' ';
        return s;
    }
    void save() {
        std::ofstream f(path_, std::ios::trunc);
        if (!f) return;
        for (const auto& b : bugs_)
            f << b.id << '\t' << clean(b.title) << '\t' << clean(b.description) << '\t' << clean(b.module) << '\t'
              << b.status << '\t' << b.severity << '\t' << b.usersAffected << '\t' << b.reproducibility << '\t'
              << b.createdAt << '\t' << b.duplicateOf << '\n';
    }
    void load() {
        std::ifstream f(path_);
        if (!f) return;
        std::string line;
        while (std::getline(f, line)) {
            std::vector<std::string> p;
            std::stringstream ss(line);
            std::string cell;
            while (std::getline(ss, cell, '\t')) p.push_back(cell);
            if (p.size() < 10) continue;
            Bug b;
            b.id = std::atoi(p[0].c_str());
            b.title = p[1]; b.description = p[2]; b.module = p[3]; b.status = p[4];
            b.severity = std::atoi(p[5].c_str());
            b.usersAffected = std::atoi(p[6].c_str());
            b.reproducibility = std::atoi(p[7].c_str());
            b.createdAt = p[8];
            b.duplicateOf = std::atoi(p[9].c_str());
            analyzer::assignPriority(b);
            bugs_.push_back(b);
            if (b.id >= nextId_) nextId_ = b.id + 1;
        }
    }

    std::string path_;
    std::vector<Bug> bugs_;
    int nextId_ = 1;
    std::mutex m_;
};
