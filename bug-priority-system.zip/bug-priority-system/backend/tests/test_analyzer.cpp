// Minimal unit tests (no framework). Run: make test
#include <cassert>
#include <iostream>
#include "../src/analyzer.hpp"

static Bug make(const std::string& t, const std::string& d, int sev, int users, int repro) {
    Bug b; b.title = t; b.description = d; b.severity = sev; b.usersAffected = users; b.reproducibility = repro;
    return b;
}

int main() {
    // Critical security bug should be P1
    Bug a = make("SQL injection on login", "Attacker can use injection to bypass password check", 5, 20000, 5);
    analyzer::assignPriority(a);
    assert(a.priority == "P1"); assert(a.category == "Security");

    // Cosmetic issue should be P4
    Bug c = make("Button colour typo", "Label has a typo", 1, 3, 2);
    analyzer::assignPriority(c);
    assert(c.priority == "P4"); assert(c.category == "UI/Cosmetic");

    // Crash with moderate impact lands in the middle
    Bug m = make("App crash on export", "Crash when exporting PDF", 3, 200, 3);
    analyzer::assignPriority(m);
    assert(m.priority == "P2" || m.priority == "P3"); assert(m.category == "Stability");

    // Score is monotonic in severity
    Bug lo = make("Report wrong total", "Incorrect total shown", 2, 100, 3);
    Bug hi = lo; hi.severity = 5;
    analyzer::assignPriority(lo); analyzer::assignPriority(hi);
    assert(hi.score > lo.score);

    // Out-of-range input is clamped
    Bug x = make("Odd", "values", 99, -5, 0);
    analyzer::assignPriority(x);
    assert(x.severity == 5 && x.usersAffected == 0 && x.reproducibility == 1);
    assert(x.score >= 0 && x.score <= 100);

    // Duplicate detection
    std::vector<Bug> existing; Bug e = make("Login page crashes on submit", "", 4, 10, 4); e.id = 7;
    existing.push_back(e);
    Bug dup = make("login page crashes on submit button", "", 4, 10, 4);
    assert(analyzer::findDuplicate(dup, existing) == 7);
    Bug other = make("Dark mode colours look odd", "", 1, 1, 1);
    assert(analyzer::findDuplicate(other, existing) == 0);

    std::cout << "All tests passed\n";
    return 0;
}
