# Software Bug Analysis and Priority Assignment System

A full-stack project: a **C++17 backend** (no external libraries) that analyses bug reports and assigns a priority, plus a **HTML/CSS/JS frontend** to report and manage bugs.

## Features
- Report bugs with severity, reproducibility, users affected, module and description
- **Automatic analysis:** category detection from keywords (Security, Stability, Data Integrity, Performance, ...)
- **Priority score (0-100)** -> P1 Critical / P2 High / P3 Medium / P4 Low
- **Duplicate detection** using Jaccard similarity of title words
- Live priority preview while typing, filters, search, status tracking, statistics
- Data persisted in `data/bugs.tsv`

## Project structure
```
backend/src/    main.cpp (HTTP server + REST API), analyzer.hpp (scoring), store.hpp (storage), json.hpp
backend/tests/  test_analyzer.cpp (unit tests)
frontend/       index.html, style.css, app.js
docs/REPORT.md  Project report
data/bugs.tsv   Sample data
Dockerfile, render.yaml, Makefile
```

## Run locally (Linux / macOS / WSL)
```bash
make test     # run unit tests
make          # build
./bin/server  # open http://localhost:8080
```
Environment variables: `PORT` (default 8080), `WEB_ROOT` (default `frontend`), `DATA_FILE` (default `data/bugs.tsv`).

## REST API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | /api/bugs | List bugs (active first, highest score first) |
| POST | /api/bugs | Create bug (JSON: title, description, module, severity, reproducibility, usersAffected) |
| POST | /api/analyze | Preview priority without saving |
| PUT | /api/bugs/{id} | Update status `{"status":"In Progress"}` |
| DELETE | /api/bugs/{id} | Delete bug |
| GET | /api/stats | Totals by priority/status/category/module |
| GET | /api/health | Health check |

## Priority formula
`score = 100 * (0.40*severity/5 + 0.25*impact + 0.20*reproducibility/5 + 0.15*keywordRisk)`
where `impact = min(1, log10(users+1)/4)`. P1 >= 75, P2 >= 55, P3 >= 35, else P4.

## Deploy (free) on Render
1. Push this folder to a GitHub repository.
2. Go to https://render.com -> New -> **Web Service** -> connect the repo.
3. Choose **Docker** runtime (it detects the Dockerfile) and the free plan, then Deploy.
4. Your live link will look like `https://bug-priority-system.onrender.com`.

Note: on free hosting the filesystem resets on redeploy/restart, so saved bugs return to the sample data.

## Live demo
Add your deployed link here: `https://<your-app>.onrender.com`
